# Test Report — v7.5.1

## Automated checks

- `npm run check` — **30/30 regression tests passed**.
- JavaScript syntax checks — passed for `app.js`, `server.mjs`, and `build.mjs`.
- `npm run build` — passed; production output generated in `dist/`.

## 3D hero regression coverage

- The hero retains the original animated network canvas, orbital rings, labels, nodes, headline and calls to action.
- The 3D stage remains present without the removed welcome tag or previous VM core.
- The import map receives a per-response nonce that matches the local server's Content Security Policy.
- The CSP explicitly permits the Three.js ES module origin while keeping unrestricted inline scripts disabled.
- The camera target is aligned to the ghost shell's geometric midpoint.

## Production preview smoke test

- `GET /` — 200 OK; import-map nonce and CSP nonce match.
- `GET /styles.css` — 200 OK.
- `GET /ghost-model.js` — 200 OK.
- `GET /app.js` — 200 OK.
- `GET /public/resume.pdf` — 200 OK.

## Visual verification boundary

The authoring environment could not resolve `cdn.jsdelivr.net`, so a complete WebGL render could not be independently observed here. The code and HTTP policy path are verified; the browser running the portfolio must be able to access jsDelivr for Three.js and OrbitControls to load.

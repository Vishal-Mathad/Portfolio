# v7.1.0
- Removed automatic welcome popup and the confusing “Instead, try this” text. The small robo-guide appears only on VM hover, focus or click.
- Reworked robo-guide styling with layered 3D shell gradients, bevels, depth, highlights, shadows and subtle floating idle animation.
- Memory game now has 20 shuffled numbered cells.
- Added Easy (15 seconds), Medium (12 seconds), Hard (8 seconds) preview modes.
- Server validates level-specific preview timing and requires 20 correct ascending selections before releasing the private source archive.

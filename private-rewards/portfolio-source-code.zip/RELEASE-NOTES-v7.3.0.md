# v7.3.0

- Replaced the entire VM orbit/core/robot-popup interface with the supplied Three.js red ghost model.
- Integrated the supplied model as a transparent canvas in the hero; drag to rotate and scroll to zoom.
- Removed the fake guide copy, navigation popup, orbit rings, nodes, labels, and VM circle.
- Added only the simple greeting: “Hey, welcome.”
- Kept the rest of the portfolio and the 20-tile memory challenge intact.

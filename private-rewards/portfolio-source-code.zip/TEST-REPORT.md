# Test Report — v6.6.0

## Automated checks

- `npm run check` — **26/26 Node regression tests passed**, with JavaScript syntax checks for the application, server and build script.
- `npm run build` — **passed**; static production output generated in `dist/`.
- Production preview HTTP smoke checks — **200 OK** for `/`, `/styles.css`, `/app.js`, `/favicon.svg` and `/public/resume.pdf`.
- ZIP archive integrity — verified after packaging.

## Coverage

- Seven-section structure, four selected projects and resume-derived technology categories.
- New terminal-style loader, staged progress, 0–100% counter, skip control and timeout fail-safe.
- Equal-height project visuals, aligned card content, card click and keyboard activation, project detail dialogs, and embedded-control event isolation.
- Four-mission Hacker Terminal: command parser, mission gating, hint/help/clear, score, progress, completion state and restart.
- Existing IAM synthetic principal switching, editable permissions, recalculated risk score, Keep/Revoke decisions, dry-run, approval gate and simulated post-execution verification.
- Existing AML synthetic analysis, Git terminal replay, Kubernetes topology, technology controls, responsive hooks and contact/resume paths.

## Manual verification boundary

Headless Chromium did not complete a reliable render pass in the authoring environment. Automated syntax, regression and production-build checks passed, but a final visual interaction check in a desktop and mobile browser remains recommended before deployment.

**Safety and accuracy:** Hacker Terminal commands are handled by a local allowlisted simulator; they do not execute in a real shell or access a network. IAM identities and permissions are synthetic and no live AWS changes occur.


## v7.2.0 verification

- Automated suite: 29 passed, 0 failed.
- Production build: successful.
- Live Node API: all three difficulty durations and 20 unique cells verified; early guess rejected; full 20-answer sequence unlocked the source reward.
- Graphical browser QA: not completed; Chromium navigation was blocked by the execution sandbox.

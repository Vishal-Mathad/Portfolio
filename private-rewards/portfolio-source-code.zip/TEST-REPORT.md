# Test report — v7.5.6

- `npm run check`: passed.
- JavaScript syntax checks: passed.
- Automated test suite: **35 passed, 0 failed**.
- `npm run build`: passed; production output generated in `dist/`.
- CSS parser validation (`tinycss2`): passed, no top-level parse errors.
- Development and production-preview HTTP smoke checks: `/`, `/ghost-model.js`, `/styles.css`, and `/app.js` returned HTTP 200.
- Headless Chromium screenshot check: not completed; Chromium stalled during startup in this environment and emitted EGL / D-Bus initialization errors. No visual browser pass is claimed.

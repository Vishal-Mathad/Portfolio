# Test Report — v6.9.0

Automated checks are run using `npm run check` and `npm run build`.

Coverage includes:
- New loader markup, initialization progress, motion keyframes and removal of the previous orbital core.
- Reward archive removal and generated dossier issuance after final mission completion.
- Existing project previews, dialogs, IAM simulation, AML visualization, navigation and responsive states.

The dossier is a client-generated HTML certificate/report. It is not the portfolio source bundle.

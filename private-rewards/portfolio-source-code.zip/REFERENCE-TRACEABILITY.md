# Reference traceability

The 46-second supplied website recording is used as the motion and visual reference. The portfolio uses original content and project-specific visualisations rather than the source site's copy, logo or product names.

| Reference characteristic | Portfolio implementation |
|---|---|
| Dark hero with a warm orange edge glow | Home section, ambient edge lighting and diagonal orange beam |
| Network paths and moving signal points | Canvas network field behind the hero typography |
| Restrained header and compact section navigation | Sticky header with seven navigation destinations |
| Alternating dark and light editorial panels | Projects/About/Fun light panels alternating with Home/Tech/Experience/Contact dark panels |
| Product/project feature cards | Four large project cards with custom technical diagrams |
| Rotating dotted globe | Interactive technology globe embedded in the Tech Stack section |
| Horizontal technology mark strip | Resume-derived logo marquee, pauses on hover |
| Feature and profile sections | About and Experience & Co-curricular sections |
| Glowing horizon contact ending | Contact section with warm horizon, perspective grid and centered call to action |
| Scene-to-scene page changes | Shared portal bloom, light beam, perspective grid and destination label on nav and scroll-driven section changes |

The implementation recreates the observable visual choreography with portfolio-specific content; it is not a pixel-identical reproduction of the original site's proprietary assets.

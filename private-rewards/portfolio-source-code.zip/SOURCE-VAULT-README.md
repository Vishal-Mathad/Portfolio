# Vishal Mathad Portfolio — Source Vault

Congratulations on completing the Terminal Operator challenge.

This archive contains the portfolio's editable source:
- `index.html` — page structure and content
- `styles.css` — visual system, responsive layouts and animations
- `app.js` — interactions, project previews and terminal challenge
- `public/` — public assets such as the resume
- `package.json`, `package-lock.json`, `build.mjs`, `server.mjs` — local development and build tooling

## Run locally

Requirements: Node.js 20+

```bash
npm install
npm run dev
```

Open the local URL printed by the development server.

To build and verify:

```bash
npm run check
npm run build
npm run preview
```

This is a static portfolio project. The terminal challenge is a deterministic browser-side simulation; it does not connect to or execute commands on real systems. No credentials, cloud secrets, or private environment files are included.

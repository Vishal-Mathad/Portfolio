# Release v7.5.3

## Visual refinements

- Vertically aligned the Engineering Foundations label and its subject list, with a clean stacked layout on small screens.
- Expanded the IAM project demo's inner dashboard width so the review interface uses more of the preview panel.
- Increased the circular technology detail tiles slightly and prevented technology names such as JavaScript from breaking into an orphan final character.

## Scope

Only CSS presentation, package version metadata, and a regression test were changed. Page copy, project descriptions, navigation, and application behaviour were left unchanged.

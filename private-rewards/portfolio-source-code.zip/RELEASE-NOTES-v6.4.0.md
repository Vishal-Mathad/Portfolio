# Release 6.4.0

## Changes

- Replaced the full-screen transition curtain and handoff overlay with native smooth anchor scrolling, active-section navigation state, and restrained fade/short-rise section reveals.
- AML starts with empty result fields. Hover, focus or pressing Run Analysis processes 480 deterministic synthetic transaction rows in batches, computes score distribution and flagged count, updates the progress bar/pipeline/chart, and only then presents the computed result. The visual is explicitly labelled as a synthetic browser demo.
- Technology category controls are evenly spaced circular nodes; technologies revealed within a selected category are circular logo badges with staggered expansion.
- Replaced Packet Rush with Signal Sync, a four-lane rhythm game featuring A/S/D/F keyboard controls, touch lane buttons, timing windows, combo bonuses, progressively faster levels, corrupted notes, five buffer lives, optional sound and persistent best score.
- Retained the seven requested sections, four projects, resume-derived technology content, project interactions and contact details.

## Validation

- 25 Node regression tests pass.
- JavaScript syntax checks pass.
- Production static build completed successfully.
- Local server smoke checks returned HTTP 200 for the page, styles, app script, favicon, resume and robots file.

# Release v7.5.5 — Balanced project preview proportions

## Changes
- Increased the media-panel height consistently across all four project cards so previews are less banner-like and closer to a balanced landscape/square proportion.
- Used shared CSS sizing tokens so the Kubernetes, IAM, Git-over-SSH, and AML previews stay aligned.
- Added responsive preview dimensions for desktop/laptop, tablet, and mobile widths.
- Preserved the existing two-column project grid where supported, all project copy, preview content, interactions, and card structure.
- Kept project action links aligned at the bottom of each text panel.

## Validation
- Automated portfolio tests pass.
- Production build succeeds.
- Built distribution mirrors the updated source styles.
- On wide desktop screens, previews now target a 440px maximum height (about a 2:1 landscape panel at the supplied screenshot width); tablet and mobile heights scale down independently.
- The IAM review rows are distributed through the taller media panel instead of leaving the lower area visually empty.

# Release v6.8.0

## Visual corrections
- Removed 3D transforms from project cards and text-bearing layers to prevent hover text blur.
- Reworked IAM review preview spacing and footer clearance while preserving the shared preview height.
- Separated AML chart labels from the synthetic-risk alert; constrained alert width and enabled wrapping.

## Fun section: Operator Challenge
- Replaced single-command objectives with four multi-step investigations: perimeter mapping, session recovery, privilege audit and evidence extraction.
- Added sequential command validation, contextual hints, XP scoring, progress tracking and restart.
- Completing all stages unlocks a downloadable portfolio source-code vault containing editable HTML, CSS, JavaScript, public assets and build notes.
- All terminal commands are handled by a deterministic client-side simulator; no real host or network is accessed.

## Verification
- `npm run check` — 27 tests passing.
- `npm run build` — passed.
- `unzip -t public/rewards/vishal-portfolio-source-v6.8.0.zip` — passed.
- Headless Chromium visual capture was attempted but did not complete; no manual visual QA claim is made.

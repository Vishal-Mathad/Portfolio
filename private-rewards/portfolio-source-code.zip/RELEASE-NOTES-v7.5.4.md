# Release v7.5.4

Responsive visual refinement based on the supplied screenshots. No portfolio copy, navigation labels, project descriptions, or application interactions were changed.

## Changes
- Increased and normalized project preview height on desktop while keeping every project card on the same visual rhythm; added tablet and mobile dimensions.
- Expanded and vertically balanced the IAM dashboard preview, with breakpoint-specific control sizing.
- Prevented the JavaScript technology label from breaking across lines inside its circular badge.
- Distributed the six Engineering Foundations items across equal grid tracks, with tablet and mobile reflow.
- Enlarged the education seal and kept “ARMY INSTITUTE OF TECHNOLOGY” inside the circle on one line.
- Aligned achievement descriptions and right-side values in stable columns, retaining a compact responsive layout.

## Validation
Automated tests and production build are run for this release.

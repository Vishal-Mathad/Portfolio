# v7.0.0 — Memory Protocol and Robo-Guide

## Fun section
- Replaced the command-line missions with a 5×5 memory challenge.
- The board displays a randomized arrangement of numbers 1–25 for 10 seconds.
- After the preview, the visitor selects the remembered positions in ascending order.
- One incorrect selection terminates the run; all 25 correct selections complete it.
- The source-code reward is served only by the Node server after server-side validation of all 25 selections.
- The source archive is stored outside the public static directory and direct static access is blocked.

## Home page
- The existing VM companion panel now automatically greets visitors shortly after landing.
- The copy says “Instead, try this” and introduces the small dimensional robo-guide.
- Hovering, focusing, or clicking the VM core still opens the greeting again.

## Running
The challenge and gated reward require the Node server:
```bash
npm install
npm run check
npm run dev
```
Open http://localhost:4173. A static-only deployment of `dist/` will not provide the memory API; deploy the Node server (or port the API routes to your hosting provider's serverless functions) to enable the game and reward.

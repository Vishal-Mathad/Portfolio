# v7.5.0 — Hero 3D model visibility fix

- Fixed the Three.js startup failure: renderer dimensions are now measured from `#hero-ghost-stage` before `WebGLRenderer.setSize()` is called. The previous code referenced `width` and `height` before they were declared, so the module threw a `ReferenceError` and the ghost never rendered.
- Added `ResizeObserver` handling so the renderer follows the hero stage dimensions when the layout changes.
- Removed the “Hey, welcome.” caption as requested.
- Preserved the original hero composition: animated network background, orbital rings, signal nodes, labels, and surrounding layout. Only the VM core has been replaced by the supplied 3D ghost.

# Release 6.5.0

## New experience

### SYSTEM FAILURE — on-call incident response
- Replaced the rhythm game with a 60-second production recovery challenge.
- Five incidents are shuffled each run: CPU saturation, database connection exhaustion, memory leak, API release regression and an unusual IAM role chain.
- Players inspect metrics, logs and health evidence; all three evidence views must be checked before remediation is unlocked.
- Four recovery actions are available: restart service, rollback deployment, scale replicas and investigate further.
- Correct actions restore time and award score/streak bonuses. Wrong actions cost 8 seconds and reduce score.
- Resolve all five incidents to stabilize production and receive a rank. Best score persists locally.

### IAM access-governance lab
- Replaced the static IAM illustration with three selectable synthetic principals.
- Permission switches recalculate risk immediately.
- Keep/Revoke decisions lead through dry-run, approval request and simulated post-execution verification.
- The interface labels the environment as a local simulation. No AWS API calls or real IAM changes occur.

### Boot sequence
- Added an animated reactor, rotating orbital rings, scanning grid, staged boot feed, 0–100% counter and Skip Intro control.
- Reduced-motion preference shortens or disables the animated effects.

## Validation

- 25/25 regression tests pass.
- JavaScript syntax checks pass.
- Production build succeeds.
- Production HTTP smoke checks return 200 for the page, application assets and resume.
- Chromium visual screenshot validation timed out in the authoring environment; manual browser review is still recommended.

# Release v6.7.0

## Visual and interaction corrections

- Replaced the green terminal-style loader with a new signal-sweep animation using the existing charcoal, ivory and orange portfolio palette. The motion uses rotating orbital rings, signal nodes, a crosshair and a deterministic progress indicator.
- Rebuilt the IAM project preview as a compact access-review interaction. Visitors can switch between three synthetic principals and record Keep or Revoke decisions. Risk, requested access and review feedback update in place.
- Simplified the IAM preview to prevent the clipped/overcrowded two-column interface seen in the previous build.
- Restored the Fun section's charcoal/orange visual treatment. Green is now reserved for the simulated terminal viewport, prompt and terminal output.
- Preserved the four-mission sandboxed Hacker Terminal game, score, hint/help commands, completion flag and TERMINAL OPERATOR reward.

## Verification

- `node --check app.js`
- `npm test`
- `npm run build`
- Production output smoke checks

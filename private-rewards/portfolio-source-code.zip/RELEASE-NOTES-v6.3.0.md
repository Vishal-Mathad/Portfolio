# Release 6.3.0

## Interaction and visual fixes

- Replaced the barely visible section fade with an explicit scene handoff: outgoing scene softens, a full-viewport focus veil covers the change, then the incoming section arrives with subtle perspective, blur and depth. Applies to navigation links, hero/contact actions and scroll-driven active-section changes.
- Added an animated welcome companion to the VM core. Hover, focus or click reveals the greeting; it exists only in the landing hero.
- Replaced the technology globe/flat groups with a circular category orbit. Clicking one of seven categories updates the center label and animates its technology logos into the adjacent detail panel. Arrow keys move between category tabs.
- AML scan now replays on every new hover/focus, not just the first time. The pipeline highlights ingestion, feature scoring, anomaly detection and review.
- Project cards retain a fixed footprint; pointer tilt rotates the card without scaling or vertical lift.
- Expanded Packet Rush to 45-second runs with wave progression, 8-clean-packet objectives, combo bonuses/multipliers, amber magnet, cyan shield and violet slow-time boosts.

## Preserved

- Seven requested portfolio sections and four selected projects.
- Existing resume, contact details, Git terminal demo, Kubernetes topology, loader, responsive navigation, project dossiers and reduced-motion preferences.

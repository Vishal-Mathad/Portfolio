# Release v7.5.2 — Wider responsive layout

- Expanded the shared page container from 1320px to 1800px so the portfolio uses more of wide desktop viewports.
- Rebalanced the desktop hero columns and enlarged the 3D model stage while retaining the signal-map rings and labels.
- Preserved the existing section copy, project content, navigation labels, buttons, and interactions.
- Kept the compact/mobile layout rules unchanged.

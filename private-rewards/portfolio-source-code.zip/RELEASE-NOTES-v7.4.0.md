# v7.4.0 — Restore signal-map composition around supplied 3D model

- Restored the original animated network canvas, three orbital rings, signal labels and OBSERVE / CONNECT / DELIVER nodes.
- Replaced only the VM core and its popup with the supplied Three.js red ghost model.
- Kept the simple “Hey, welcome.” message.
- Increased model framing and made the outer and inner surfaces double-sided to prevent invisible geometry from face-culling.
- Preserved the rest of the portfolio and memory challenge.

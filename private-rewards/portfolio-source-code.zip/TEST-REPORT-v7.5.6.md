# Test report — v7.5.6

- `npm run check`: passed.
- Node syntax checks (`app.js`, `server.mjs`, `build.mjs`): passed.
- Automated test suite: **35 passed, 0 failed**.
- `npm run build`: passed; production output generated in `dist/`.
- CSS parser validation (`tinycss2`): passed, no top-level parse errors.
- Development-server HTTP smoke checks: `/`, `ghost-model.js`, and `styles.css` returned successfully.
- Headless Chromium screenshot check: not completed; Chromium stalled during startup in this environment and emitted EGL / D-Bus initialization errors. No visual browser pass is claimed.

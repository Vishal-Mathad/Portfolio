# v7.5.1 — 3D robot visibility and alignment fix

- Fixed the root cause of the missing robot in the local Node server: the Content Security Policy previously blocked both the inline import map and the Three.js ES modules loaded from jsDelivr.
- Added a fresh per-response CSP nonce to the import map and explicitly allowed the jsDelivr module origin. Unrestricted inline scripts remain disabled.
- Added a CDN preconnect to reduce module startup latency.
- Re-aimed the camera at the geometric midpoint of the robot so the model is centred in the existing orbital rings.
- Kept the original hero headline, animated background network, rings, signal labels, navigation and button layout unchanged.
- Added WebGL initialization diagnostics and accessible canvas labeling.
- Validation: `npm run check` passes all 30 regression tests; `npm run build` succeeds. Runtime nonce/CSP headers were smoke-tested against the local server. Visual browser rendering could not be independently confirmed in this network-restricted authoring environment.

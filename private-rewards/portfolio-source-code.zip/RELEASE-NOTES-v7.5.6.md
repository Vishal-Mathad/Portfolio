# Release v7.5.6

## 3D robot zoom guard
- Reduced wheel/pinch zoom speed.
- Restricted OrbitControls camera distance so the robot cannot zoom into a clipped close-up.
- Adjusted zoom limits by stage width and re-applied them after each resize.
- Kept drag-to-rotate and the full orbit-angle range available.

## Responsive layouts
- Tuned the hero split and type scale for laptop widths.
- Rebalanced navigation and hero proportions at tablet widths.
- Stacked project cards on portrait tablets and smaller screens.
- Tuned hero model stage, orbit labels and actions for phone widths.
- Preserved all existing page copy, project content and interactions.
